#!/bin/sh
./CustomPlayer
