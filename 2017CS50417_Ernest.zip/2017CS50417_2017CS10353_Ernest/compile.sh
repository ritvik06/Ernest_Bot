#!/bin/sh
g++ -std=c++11 earnestBot.cpp -o CustomPlayer

